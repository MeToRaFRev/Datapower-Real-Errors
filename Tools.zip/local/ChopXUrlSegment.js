if(!session.parameters.X) session.parameters.X = '1'
var sm = require('service-metadata');
var uri = sm.getVar('var://service/URI');
var partsCut = parseInt(session.parameters.X,10)+1
console.error(session.parameters.X)
console.error(partsCut)
var parts = uri.split("/");
var newUri = "";
for (var i = partsCut; i < parts.length; ++i) newUri += "/" + parts[i];

sm.setVar('var://service/URI', newUri);
