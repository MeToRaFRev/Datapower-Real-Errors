if (!session.parameters.BaseURL)
  session.parameters.BaseURL = "https://moh.co.il";
if (!session.parameters.Timeout) session.parameters.Timeout = 45;
if (!session.parameters.AcceptData)
  session.parameters.AcceptData = "application/json";
if (!session.parameters.Cors) session.parameters.Cors = false;
var sm = require("service-metadata");
var hm = require("header-metadata");
var urlopen = require("urlopen");

sm.setVar("var://service/mpgw/skip-backside", true);

var uri = sm.getVar("var://service/URI");
var method = sm.getVar("var://service/protocol-method");

session.input.readAsBuffer(function (error, buffer) {
  if (error) {
    hm.response.statusCode = "500 Internal Server Error";
    session.output.write({
      status: "error",
      message: hm.response.reasonPhrase,
    });
    throw error;
  } else {
    var callDetails = {
      target: session.parameters.BaseURL + uri,
      method: method,
      headers: { Accept: session.parameters.AcceptData },
      timeout: parseInt(session.parameters.Timeout, 10),
    };
    if (method.toLowerCase() != "get" && method.toLowerCase() != "delete")
      callDetails["data"] = buffer.toString();
    for (var header in hm.current.get())
      if (header.toLowerCase() != "host")
        callDetails.headers[header] = hm.current.get(header);
    var ctx = session.name("invoker") || session.createContext("invoker");
    urlopen.open(callDetails, function (error, response) {
      if (error) {
        if (response != null && response.hasOwnProperty("statusCode"))
          hm.response.statusCode =
            response.statusCode + " " + response.reasonPhrase;
        else hm.response.statusCode = "500 Internal Server Error";
        ctx.write(XML.parse("<status><statusCode>500</statusCode></status>"));
        session.output.write({
          status: "error",
          message: hm.response.reasonPhrase,
        });
      } else {
        for (var header in response.headers)
          if (header.toLowerCase() != "content-length")
            hm.response.set(header, response.headers[header]);
        if (session.parameters.Cors) {
          hm.response.set("Access-Control-Allow-Origin", "*");
hm.response.set("Access-Control-Allow-Headers","Authorization")
}
        response.readAsBuffer(function (error, responseData) {
          if (error) {
            ctx.write(
              XML.parse("<status><statusCode>500</statusCode></status>")
            );
            hm.response.statusCode = "500 Internal Server Error";
            session.output.write({
              status: "error",
              message: hm.response.reasonPhrase,
            });
            throw error;
          } else {
            ctx.write(
              XML.parse(
                "<status><statusCode>" +
                  response.statusCode +
                  "</statusCode></status>"
              )
            );
            hm.response.statusCode = response.statusCode;
            session.output.write(responseData);
          }
        });
      }
    });
  }
});
